# robot
[基于百度语音识别](http://yuyin.baidu.com)

[百度tts](https://github.com/DelightRun/PyBaiduYuyin)

[图灵机器人的语音小助手](http://www.tuling123.com)


